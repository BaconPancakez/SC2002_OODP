package lab5.src;

public interface Searchable<T> {
    boolean search(String keyword);
}
