package lab4.p2.src.Shape;

public interface Shape {
    public double area();
}
